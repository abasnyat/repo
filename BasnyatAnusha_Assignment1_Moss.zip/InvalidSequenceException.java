/**
 * @author Anusha Basnyat 
 */

public class InvalidSequenceException extends Exception {
	public InvalidSequenceException()
	{
		
	}
	
	/**
	 * Constructor that will take a message, this will be displayed if the InvalidSequenceException is thrown.
	 * @param message
	 */
	public InvalidSequenceException(String message)
	{
		super(message);
	}

}
