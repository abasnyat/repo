/**
 * @author Anusha Basnyat 
 */


public class IsWeakPasswordException extends RuntimeException{
	public IsWeakPasswordException()
	{
		
	}

	/**
	 * Contructor that will take a message, this will be displayed if the IsWeakException is thrown.
	 * @param message
	 */
	public IsWeakPasswordException(String message)
	{
		super(message);
	}
}
