/**
 * @author Anusha Basnyat 
 */

public class NoUpperAlphaException extends Exception {
	public NoUpperAlphaException()
	{
		
	}
	
	/**
	 * Constructor that will take in a message, this will be displayed if NoUpperAlphaException is thrown.
	 * @param message
	 */
	public NoUpperAlphaException(String message)
	{
		super(message);
	}

}
