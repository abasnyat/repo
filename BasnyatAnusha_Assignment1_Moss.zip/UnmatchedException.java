/**
 * @author Anusha Basnyat 
 */
public class UnmatchedException extends Exception{
	public UnmatchedException()
	{
		
	}
	
	/**
	 * Constructor that will take a message, this will be displayed if the UnmatchedException is thrown.
	 * @param message
	 */
	public UnmatchedException(String message)
	{
		super(message);
	}

}
