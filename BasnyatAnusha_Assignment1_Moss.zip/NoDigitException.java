/**
 * @author Anusha Basnyat 
 */

public class NoDigitException extends Exception{
	public NoDigitException()
	{
		
	}
	
	
	
	public NoDigitException(String message)
	{
		super(message);
	}
	

}
