/**
 * @author Anusha Basnyat 
 */
import java.util.ArrayList;


public class PasswordCheckerUtility {
	/**
	 * Checks if the password is valid
	 * @param passwordString
	 * @return boolean value
	 * @throws LengthException
	 * @throws NoDigitException
	 * @throws NoUpperAlphaException
	 * @throws NoLowerAlphaException
	 * @throws InvalidSequenceException
	 * @throws IsWeakPasswordException
	 */
	public static boolean isValidPassword(String passwordString) throws LengthException, NoDigitException, NoUpperAlphaException, InvalidSequenceException, IsWeakPasswordException
		{		
			String pass;
			pass = passwordString;
			
			
			
			
			if(pass.length()<6)
			{
				throw new LengthException("The password must be at least 6 characters long.");
			}
			
			
			
			
			boolean upper=false;
			
			
			for(int x=0; x<pass.length(); x++)
			{
				if(Character.isLetter(pass.charAt(x)) && Character.isUpperCase(pass.charAt(x)))
				{
					upper=true;
				}
			}
				
			
			if(upper==false)
			{
				throw new NoUpperAlphaException("The password must contain at least one uppercase alphabetic character.");
			}
				
		
			
			
			boolean lower=false;
			
			
			for(int x=0; x<pass.length(); x++)
			{
				if(Character.isLetter(pass.charAt(x)) && Character.isLowerCase(pass.charAt(x)))
				{
					lower=true;
				}
			}
				
			
			if(lower==false)
			{
				throw new  NoLowerAlphaException ("The password must contain at least one lowercase alphabetic character.");
			}
			
			
			
			boolean digit=false;
			
			for(int x=0; x<pass.length(); x++)
			{
				if(Character.isDigit(pass.charAt(x)))
				{
					digit=true;
				}
			
			}
				
		
			if(digit==false)
			{
				throw new NoDigitException("The password must contain at least one digit.");
			}
						
			
			
						
			for(int x=0; x<pass.length()-2; x++)
			{
				if(pass.charAt(x)==pass.charAt(x+1) && (pass.charAt(x) == pass.charAt(x+2)))
				{
					throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence.");
				}
			}
			return true;
			
					
		}
	
	/**
	 * Checks if the password is weak.
	 * @param string
	 * @return boolean value
	 */
	public static boolean isWeakPassword(String string) {
		String pass;
		
		pass = string;
		if(pass.length() > 5 && pass.length() < 10)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	/**
	 * Checks if the password in the file is valid
	 * @param passwords
	 * @return noValidPasswords
	 */
	public static ArrayList<String> validPasswords(ArrayList<String> passwords)
	{
		ArrayList<String> noValidPasswords;
		
		noValidPasswords = new ArrayList<String>();
		String messageError = null;
		
		for(int j=0; j<passwords.size(); j++)
		{
			try
			{
				isValidPassword(passwords.get(j));
			}
			
			catch (LengthException e)
			{
				messageError=passwords.get(j) + " The password must be at least 6 characters long.";
				noValidPasswords.add(messageError);	
			}
			catch (NoDigitException e)
			{
				messageError=passwords.get(j) + " The password must contain at least one digit.";
				noValidPasswords.add(messageError); 
			}
			catch (NoUpperAlphaException e)
			{
				messageError=passwords.get(j) + " The password must contain at least one uppercase alphabetic character.";
				noValidPasswords.add(messageError);
			}
			catch (NoLowerAlphaException e)
			{
				messageError=passwords.get(j) + " The password must contain at least one lowercase alphabetic character.";
				noValidPasswords.add(messageError);
			}
			catch (InvalidSequenceException e)
			{
				messageError=passwords.get(j) + " The password cannot contain more than two of the same character in sequence.";
				noValidPasswords.add(messageError);
			}
			catch (IsWeakPasswordException e)
			{
				messageError=passwords.get(j) + " The password is OK but weak.";
				noValidPasswords.add(messageError);
			}
			
		}
		return noValidPasswords;
	}


	
}
