/**
 * @author Anusha Basnyat 
 */


public class LengthException extends Exception {
	public LengthException()
	{
		
	}
	
	
	/**
	 * Contructor that will take a message, this will be displayed if the LengthException is thrown.
	 * @param message
	 */
	public LengthException(String message)
	{
		super(message);
	}
}
