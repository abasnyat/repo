/**
 * Sorted Double Linked List class
 * @author anushab
 * 
 */

import java.util.ListIterator;


public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
	
	// creates empty list
	java.util.Comparator<T> comp = null;
	
	/**
	 *  Creates an empty list that is associated with the specified comparator
	 * @param comparator02 - Comparator to compare data elements
	 */
	public SortedDoubleLinkedList(java.util.Comparator<T> comparator02) {
		
		comp = comparator02;
	}
	
	/**
	 *  Inserts the specified element at the correct position in the sorted list.
	 * @param data - the data to be added to the list
	 * @return a reference to the current object
	 */
	public SortedDoubleLinkedList<T> add(T data01) {
		
		if (data01 == null) {
			
			return this;
		}

		Node newnode = new Node(data01, null, null);
		
		if (header == null) {
			
			header = tail = new Node(data01, null, null);
		}
		
		else {
			
			if (comp.compare(data01, header.item) <= 0) {
				
				newnode.next = header;
				header = newnode;
			}
			
			else if (comp.compare(data01, tail.item) >= 0) {
				
				tail.next = newnode;
				tail = newnode;
			}
			
			else {
				
				Node next = header.next;
				
				Node prev = header;
				
				while (comp.compare(data01, next.item) > 0) {
					
					prev = next;
					next = next.next;
				}
				
				prev.next = newnode;
				newnode.next = next;
					
			}
			
		}
		
		size++;
		
		return this;
	}

	
	/**
	 * This operation is invalid for a sorted list.
	 */
	public BasicDoubleLinkedList<T> addToEnd(T data01) {
		
		throw new UnsupportedOperationException();
	}

	
	/**
	 * This operation is invalid for a sorted list.
	 */
	public BasicDoubleLinkedList<T> addToFront(T data01) {
		
		throw new UnsupportedOperationException();
	}

	
	/**
	 * Implements the iterator by calling the super class iterator method
	 */
	public ListIterator<T> iterator() {
		
		return new iterr();
	}
	
	/**
	 * Implements the remove operation by calling the super class remove method
	 */
	public SortedDoubleLinkedList<T> remove(T data01, java.util.Comparator<T> comparator01) {
		
		Node next = header;
		Node prev = null;
		
		while (next != null) {
		
			if (comparator01.compare(next.item, data01) == 0) {
				
				size--;
				
				if (prev != null) {
					
					prev.next = next.next;
				}
				
				else {
					
					header = next.next;
				}
				
				if (next == tail) {
					
					tail = prev;
				}
			}
			
			prev = next;
			next = next.next;
		}
		
		return this;
	}
}




