
/**
 * Basic Double Linked List class
 * @author anushab
 * 
 */

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.NoSuchElementException;


public class BasicDoubleLinkedList<T> implements java.lang.Iterable<T> {
	
	
	/**
	 * class node
	 * @author anushab
	 *
	 */
	protected class Node {
		
		protected T item;
		protected Node next, previous;
		
		//node constructor
		protected Node(T item, Node next, Node previous) {
			
			this.item = item;
			this.next = next;
			this.previous = previous;
		}
	}

	protected int size;
	protected Node header, tail;
	
	
	/**
	 * constructor
	 */
	public BasicDoubleLinkedList() {
		
		size = 0;
		header = tail = null;
	}
	
	
	/**
	 * Notice you must not traverse the list to compute the size
	 * This method just returns the value of the instance variable you use to keep track of size
	 * @return
	 */
	public int getSize() {
		
		return size;
	}
	
	
	/**
	 * Adds an element to the end of the list. Do not use iterators to implement this method
	 * @param elem - the data for the Node within the linked list
	 * @return reference to the current object
	 */
	public BasicDoubleLinkedList<T> addToEnd(T data01) {
		
		Node temp = new Node(data01, null, tail);
		
		if (tail != null) {
			
			tail.next = temp;
		}
		
		tail = temp;
		
		if (header == null) {
			
			header = temp;
		}
		
		size++;
		
		return this;
	}
	
	
	/**
	 * Adds element to the front of the list. Do not use iterators to implement this method
	 * @param elem - the data for the Node within the linked list
	 * @return reference to the current object
	 */
	public BasicDoubleLinkedList<T> addToFront(T data01) {
		
		Node temp = new Node(data01, header, null);
		
		if (header != null) {
			
			header.previous = temp;
		}
		
		header = temp;
		
		if (tail == null) {
			
			tail = temp;
		}
		
		size++;
		
		return this;
	}
	
	
	/**
	 * Returns but does not remove the first element from the list
	 * If there are no elements the method returns null. Do not implement this method using iterators
	 * @return
	 */
	public T getFirst() {
		
		return header.item;
	}
	
	
	/**
	 * Returns but does not remove the last element from the list. If there are no elements the method returns null
	 * Do not implement this method using iterators
	 * @return
	 */
	public T getLast() {
		return tail.item;
	}
	
	
	/**
	 * iterator method
	 */
	public ListIterator<T> iterator() {
		
		return new iterr();
	}
	
	
	/**
	 * Removes the first instance of the targetData from the list
	 * @param data01 - the data element to be removed
	 * @param comparator - the comparator to determine equality of data elements
	 * @return
	 */
	public BasicDoubleLinkedList<T> remove(T data01, java.util.Comparator<T> comparator) {
		
		Node prev = null, curent = header;
		
		while (curent != null) {
			
			if (comparator.compare(curent.item, data01) == 0) {
				
				if (curent == header) {
					
					header = header.next;
					curent = header;
					}
				else if (curent == tail) {
					curent = null;
						tail = prev;
						prev.next = null;
				}
				
				else {
					
					prev.next = curent.next;
					curent = curent.next;
				}
				
				size--;
			}
			
			else {
				
				prev = curent;
				curent = curent.next;
			}
		}
		
		return this;
	}
	
	
	/**
	 * Removes and returns the first element from the list
	 * If there are no elements the method returns null
	 * Do not implement this method using iterators
	 * @return data element or null
	 */
	public T retrieveFirstElement() {
		
		if (size == 0) {
			
			throw new NoSuchElementException("Linked list is empty");
		}
		
		Node temp = header;
		header = header.next;
		header.previous = null;
		size--;
		
		return temp.item;
	}
	
	
	/**
	 * Removes and returns the last element from the list
	 * If there are no elements the method returns null
	 * Do not implement implement this method using iterators
	 * @return data element or null
	 */
	public T retrieveLastElement() {
		
		if (header == null) {
			
			throw new NoSuchElementException("Linked list is empty");
		}
		
		Node curentNode = header;
		Node previousNode = null;
		
		while (curentNode != null) {
			
			if (curentNode.equals(tail)) {
				
				tail = previousNode;
				break;
			}
			
			previousNode = curentNode;
			curentNode = curentNode.next;
		}
		
		size--;
		
		return curentNode.item;
	}
	
	
	/**
	 * Returns an arraylist of the items in the list from head of list to tail of list
	 * @return an arraylist of the items in the list
	 */
	public ArrayList<T> toArrayList() {
		
		ArrayList<T> temp = new ArrayList<T>();
		ListIterator<T> iterator1 = new iterr();
		
		while (iterator1.hasNext()) {
			
			temp.add(iterator1.next());
		}
		
		return temp;
	}
	
	
	/**
	 * iter class
	 * @author rashiqc
	 *
	 */
	public class iterr implements ListIterator<T> {
		
		private Node curent;
		private Node last;
		
		public iterr() {
			
			curent = header;
			last = null;
		}
		
		public T next() {
			
			if(curent != null) {
				
				T returnData = curent.item;
				last = curent;
				curent = curent.next;
				
				if(curent != null) {
					curent.previous = last;
				}
				
				return returnData;
			}
			
			else {
			
				throw new NoSuchElementException();
			}
		}
		
		public boolean hasNext() {
			
			return curent!=null;
		}
		
		public T previous() {
			
			if(last != null) {
				
				curent = last;
				last= curent.previous;
				T returnData = curent.item;
				
				return returnData;
			}
			
			else {
				
				throw new NoSuchElementException();
			}
		}
		
		public boolean hasPrevious() {
			
			return last!=null;
		}
		
		public void set(T elem) {
			
			curent.item = elem;
		}
		
		public int nextIndex() {
			
			throw new UnsupportedOperationException();
		}
		
		public int previousIndex() {
			
			throw new UnsupportedOperationException();
		}
		
		public void remove() {
			
			throw new UnsupportedOperationException();
		}
		
		public void add(T e) {
			
			throw new UnsupportedOperationException();
		}
	}
}




