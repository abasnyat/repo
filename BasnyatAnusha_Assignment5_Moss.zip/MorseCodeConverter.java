/**
 * The MorseCodeConverter contains a static MorseCodeTree object and constructs (calls the constructor for) the MorseCodeTree
 * 
 * @author Anusha Basnyat 
 */


import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter 
{
	
	private static MorseCodeTree t = new MorseCodeTree();
	
	public MorseCodeConverter() 
{
		
	}
	
	
	/**
	 * Converts Morse code into English. Each letter is delimited by a space (� �). Each word is delimited by a �/�
	 * 
	 * @param code - the morse code
	 * 
	 * @return the English translation
	 */
	public static java.lang.String convertToEnglish(java.lang.String code)
 {
		
		String output = "";
		String[] word;
		String[] letter;
		
		word = code.split(" / ");
		
		
		for(int x = 0; x < word.length; x++) {//
			
			letter = word[x].split(" ");
			
			for(int y = 0; y < letter.length; y++) {//
				
				output += t.fetch(letter[y]);
           }
           
           output += " ";
		}
		
		output = output.trim();
		
		return output;
		
	}
	
	/**
	 * Converts a file of Morse code into English Each letter is delimited by a space (� �). Each word is delimited by a �/�
	 * 
	 * @param codeFile - name of the File that contains Morse Code
	 * 
	 * @return the English translation of the file
	 * 
	 * @throws java.io.FileNotFoundException
	 */
	public static java.lang.String convertToEnglish(java.io.File codeFile) throws java.io.FileNotFoundException 
{
		
		String output = "";
		ArrayList<String> line = new ArrayList<String>();
		String[] word;
		String[] letter;
		
		Scanner inputFile;
		inputFile = new Scanner(codeFile);
		
		while (inputFile.hasNext()) {//
			
			line.add(inputFile.nextLine());
		}
          
       inputFile.close();
       
       for(int x = 0; x < line.size(); x++) {//
    	   
    	   word = line.get(x).split(" / ");
    	   
    	   for(int y = 0; y < word.length; y++) {//
    		   
    		   letter = word[y].split(" ");
    		   
    		   for(int z = 0; z < letter.length; z++) {//
    			   
    			   output += t.fetch(letter[z]); 
    		   }
    		   
    		   output += " "; 
    	   }
       }
       
       output = output.trim();
       
       return output;
	}

  
   /**
   * returns a string with all the data in the tree in LNR order with an space in between them
   * Uses the toArrayList method in MorseCodeTree It should return the data in this order:
   * "h s v i f u e l r a p w j b d x n c k y t z g q m o"
   * Note the extra space between j and b - that is because there is an empty string that is the root,
   * and in the LNR traversal, the root would come between the right most child of the left tree (j) and the left most child of the right tree (b)
   * This is used for testing purposes to make sure the MorseCodeTree has been built properly
   *
   * @return the data in the tree in LNR order separated by a space.
   */
   public static java.lang.String printTree() 
{
       
	   ArrayList<String> treeData = new ArrayList<String>();
      
       treeData = t.toArrayList();
      
       String print = "";
      
       for(int x = 0; x < treeData.size(); x++) 
{//
           
    	   print += treeData.get(x) + " ";  
       }
      
       return print;
   }
}




