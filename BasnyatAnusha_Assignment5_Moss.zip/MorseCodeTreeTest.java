/**
 * 
 * 
 * @author Anusha Basnyat 
 */


import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MorseCodeTreeTest {
	
	MorseCodeTree tree;
	

	@BeforeEach
	void setUp() throws Exception {
		
		tree = new MorseCodeTree();
	}
	
	
	@AfterEach
	void tearDown() throws Exception {
		
		tree = null;
	}
	
	
	@Test
	void testToArrayList() {
		
		String correctResult = "h s v i f u e l r a p w j  b d x n c k y t z g q m o";
		ArrayList<String> list=tree.toArrayList();
		assertEquals(list.get(0), "h");
		assertEquals(list.get(1), "s");
		assertEquals(list.get(2), "v");
		assertEquals(list.get(3), "i");
		assertEquals(list.get(4), "f");
		assertEquals(list.get(5), "u");
		
	}
	
	
	@Test
	void testInsert() {
		
		tree.insert("..", "i");
		tree.insert(".--.-", "6");
		tree.insert("-.-..", "9");
		
		assertEquals("i", tree.fetch(".."));
		assertEquals("6", tree.fetch(".--.-"));
		assertEquals("9", tree.fetch("-.-.."));
		
		
	}
	
	
	@Test
	void testGetRoot() {
		
		TreeNode<String> nodeTree= new TreeNode<String>("yep");
		tree.setRoot(nodeTree);
		
		assertEquals(nodeTree.getData(), "yep");
		
	}
	
	
	@Test
	void testFetch() {
		
		tree.insert("...--", "1");
		tree.insert("--...", "2");
		tree.insert("..-..", "3");
		
		assertEquals(tree.fetch("...--"), "1");
		assertEquals(tree.fetch("--..."), "2");
		assertEquals(tree.fetch("..-.."), "3");	
	}
}




