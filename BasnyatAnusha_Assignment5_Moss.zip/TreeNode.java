/**
 * the external Tree Node for Linked Trees
 * 
 * @author Anusha Basnyat 
 *
 * @param <T>
 */


public class TreeNode<T> {
	
	protected T data;
	protected TreeNode<T> rightChild;
	protected TreeNode<T> leftChild;

	
	/**
	 * empty constructor
	 */
	public TreeNode() {
		//null
	}
	
	
	/**
	 * create a new TreeNode with left and right child set to null and data set to the dataNode
	 * @param dataNode
	 */
	public TreeNode(T dataNode) {//data node with null for right and left child
		
		this.data = dataNode;
		this.leftChild = null;
		this.rightChild = null;
	}
	
	
	/**
	 * used for making deep copies
	 * @param node
	 */
	public TreeNode(TreeNode<T> node) {//deep copy constructor
		
		new TreeNode<>(node);
	}
	
	
	/**
	 * return the data within this TreeNode
	 * @return data
	 */
	public T getData() {
		
		return data;
	}

	
	/**
	 * sets data
	 * @param data
	 */
	public void setData(T data) {
		
		this.data = data;
	}
	
	
	/**
	 * returns rightchild
	 * @return rightChild
	 */
	public TreeNode<T> getRightChild() {
		
		return rightChild;
	}

	
	/**
	 * sets rightchild
	 * @param rightChild
	 */
	public void setRightChild(TreeNode<T> rightChild) {
		
		this.rightChild = rightChild;
	}

	
	/**
	 * returns leftchild
	 * @return leftChild
	 */
	public TreeNode<T> getLeftChild() {
		
		return leftChild;
	}

	
	/**
	 * sets leftchild
	 * @param leftChild
	 */
	public void setLeftChild(TreeNode<T> leftChild) {
		
		this.leftChild = leftChild;
	}
}




