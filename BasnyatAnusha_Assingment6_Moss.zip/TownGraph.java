/**
 * @author Anusha Basnyat
 * 
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


public class TownGraph implements GraphInterface<Town, Road> {

	private Set<Road> roadList = new HashSet();
	
	private Set<Town> townList = new HashSet();
	Set<Town> passingTowns;
	Set<Town> passedTowns;
	ArrayList<String>loc = new ArrayList<String>();
	
	/**
	 * 
	 */
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
	
		Iterator<Road> it = roadList.iterator();
		Set<Town> newTowns = new HashSet();
		
		newTowns.add(sourceVertex);
		newTowns.add(destinationVertex);
		
		while(it.hasNext()) {
			
			Road temp = it.next();
			
			if(temp.getTowns().equals(newTowns)) {
				
				return temp;
			}
		}
		return null;
	}

	/**
	 * 
	 */
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		
		sourceVertex.getAdjacentTowns().add(destinationVertex);
		destinationVertex.getAdjacentTowns().add(sourceVertex);
		sourceVertex.addTowns(destinationVertex);
		destinationVertex.addTowns(sourceVertex);
		
		Road road = new Road(sourceVertex, destinationVertex, weight, description);
	    
		roadList.add(road);
		
		return road;
	}

	/**
	 * 
	 */
	public boolean addVertex(Town v) {
		
		return townList.add(v);
	}

	/**
	 * 
	 */
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		
		Iterator<Road> it = roadList.iterator();
		Set<Town> newTowns = new HashSet();
		newTowns.add(sourceVertex);
		newTowns.add(destinationVertex);
		
		while(it.hasNext()) {
			
			Road road = it.next();
			if(road.getTowns().equals(newTowns)) {
			return true;
			}
		}
		return false;
	}

	/**
	 * 
	 */
	public boolean containsVertex(Town v) {
		
		boolean flag = townList.contains(v);
		return flag;
	}

	/**
	 * 
	 */
	public Set<Road> edgeSet() {
		
		return roadList;
	}

	/**
	 * 
	 */
	public Set<Road> edgesOf(Town vertex) {
		
		Set<Road> newRoads = new HashSet();
		Iterator<Road> it = roadList.iterator();
		
		while(it.hasNext()) {
			
			Road road = it.next();
			
			if(road.getTowns().contains(vertex)) {
				
				newRoads.add(road);
			}
		}
		return newRoads;
	}

	/**
	 * 
	 */
	public boolean removeVertex(Town v) {
		
		boolean flag = false;
		
		for(Road road :edgesOf(v)){
			
			Iterator iter = road.getTowns().iterator();
			Town t1 = (Town) iter.next();
			Town t2 = (Town) iter.next();
			removeEdge(t1, t2, road.getWeight(), road.getName());
		}
		return townList.remove(v);
	}

	/**
	 * 
	 */
	public Set<Town> vertexSet() {
		
		return townList;
	}

	/**
	 * 
	 */
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		
		loc.clear();
		passingTowns = new HashSet();
		passedTowns = new HashSet(townList);
		Town town1 = null;
		Town town2 = null;
		
		for(Town town: townList) {
			
			if(town.getName().equals(sourceVertex.getName())) {
				
				town1 = town;
				town1.setAdjacentTowns(town.getAdjacentTowns());
			}
			
			if(town.getName().equals(destinationVertex.getName())) {
				
				town2 = town;
			}
		}
		
		town1.setWeight(0);
		passingTowns.add(town1);
		passedTowns.remove(town1);
		this.dijkstraShortestPath(town1);
		
		getShortestPath(town1, town2);
		
		Collections.reverse(loc);
		
		for(Town town: townList) {
			
			town.resetLoc();
		}
		return loc;
		
	}

	/**
	 * 
	 * @param town1
	 * @param town2
	 */
	private void getShortestPath(Town town1, Town town2) {
		
		try {
			
			Road t = getEdge(town2.gettTown(), town2);
			StringBuilder path = new StringBuilder();
			path.append(town2.gettTown().getName());
			path.append(" via ");
			path.append(t.getName());
			path.append(" to ");
			path.append(town2.getName());
			path.append(" ");
			path.append(t.getWeight());

			loc.add(path.toString());
			
			if (!(town2.gettTown().equals(town1))) {
				
				getShortestPath(town1, town2.gettTown());
			}
		}
		catch(NullPointerException e) {

			loc.clear();
			loc.add("No such path found");
		}
	}

	/**
	 * 
	 */
	public void dijkstraShortestPath(Town sourceVertex) {
		
		Boolean finding = false;
		
		while (!passedTowns.isEmpty() && !finding) {
			
			finding = true;
			int shortest = Integer.MAX_VALUE;
			Town closestTown = null;
			
			for (Town visitedTown : passingTowns) {

				Set<Town> adjTowns = visitedTown.getAdjacentTowns();

				Set<Town> adjTownsUnVisited = new HashSet<>();
				
				for (Town town : adjTowns) {
					
					if (passedTowns.contains(town)) {
						
						adjTownsUnVisited.add(town);
					}
				}
				
				for (Town unvisitedTown : adjTownsUnVisited) {
					
					int totalWeight = getTotalWeight(unvisitedTown, visitedTown, sourceVertex);
					
					if (totalWeight < shortest) {
						
						shortest = totalWeight;

						closestTown = unvisitedTown;

						unvisitedTown.settTown(visitedTown);
					}
				}
			}
			
			if (closestTown != null) {
				
				closestTown.setWeight(shortest);
				passingTowns.add(closestTown);
				passedTowns.remove(closestTown);
				finding = false;
			}
		}
	}

	/**
	 * 
	 */
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		
		sourceVertex.removeTowns(destinationVertex);
		destinationVertex.removeTowns(sourceVertex);
		Road temp = new Road(sourceVertex, destinationVertex, weight, description);
		return roadList.remove(temp) ? temp : null;
	}
	
	/**
	 * 
	 * @param unvisitedTown
	 * @param visitedTown
	 * @param sourceVertex
	 * @return
	 */
	private int getTotalWeight(Town unvisitedTown, Town visitedTown, Town sourceVertex) {
		
		if (unvisitedTown.equals(sourceVertex))
			
			return 0;

		return visitedTown.getWeight() + getEdge(visitedTown, unvisitedTown).getWeight();
	}
}




