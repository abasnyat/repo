/**
 * holds the name of the town and a list of adjacent towns, and other fields as desired, and the traditional methods
 * 
 * @author Anusha Basnyat
 * 
 */

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Town implements Comparable<Town> {
	
	private String name;
	private Set<Town> adjTowns;
	private int weight;
	private Town tTown;
	
	private ArrayList<Road> roadList;
	
	/**
	 * constructor
	 * 
	 * @param name
	 */
	public Town(String name) {
		
		this.name = name;
		adjTowns = new HashSet();
		weight = Integer.MAX_VALUE;
		tTown = null;
	}////
	
	/**
	 * copy constructor
	 * @param template
	 */
	public Town(Town template) {
		
		new Town(template);
	}////

	
	public boolean equals(Object o) {
		
		if (this == o)
			
			return true;
		
		if (o == null)
			
			return false;
		if (getClass() != o.getClass())
			
			return false;
		
		Town t = (Town) o;
		
		if (name == null) {
			
			if (t.name != null)
				
				return false;
		}
		
		else if (!name.equals(t.name))
			
			return false;
		
		return compareTo((Town) o) == 0;
	}////

	/**
	 * returns the town's name
	 * @return town's name
	 */
	public String getName() {
		
		return name;
	}////

	/**
	 * 
	 */
	public int hashCode() {
		
		final int prime = 31;
		int res = 1;
		res = prime * res + ((name == null) ? 0 : name.hashCode());
		return res;
	}////

	/**
	 * 
	 * @param t
	 */
	public void addTowns(Town t) {
		
		adjTowns.add(t);
	}
	
	/**
	 * 
	 * @param t
	 */
	public void removeTowns(Town t) {
		
		adjTowns.remove(t);
	}
	
	/**
	 * 
	 * @return
	 */
	public Set<Town> getAdjacentTowns() {
		
		return adjTowns;
	}
	
	/**
	 * 
	 * @param adjacentTowns
	 */
	public void setAdjacentTowns(Set<Town> adjacentTowns) {
		
		this.adjTowns = adjacentTowns;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getWeight() {
		
		return weight;
	}

	/**
	 * 
	 * @param weight
	 */
	public void setWeight(int weight) {
		
		this.weight = weight;
	}

	/**
	 * to string method
	 */
	public String toString() {
		
		return "Town [name = " + name + "]";
	}

	/**
	 * compare to method
	 */
	public int compareTo(Town t) {
		
		if(t.name.compareTo(name) == 0) {
			
			return 0;
		}
		
		else
			
			return -1;
	}

	/**
	 * 
	 */
	public void resetLoc() {
		
		weight = Integer.MAX_VALUE;
		tTown = null;
	}

	/**
	 * 
	 * @return
	 */
	public Town gettTown() {
		
		return tTown;
	}

	/**
	 * 
	 * @param tTown
	 */
	public void settTown(Town tTown) {
		
		this.tTown = tTown;
	}

}




