/**
 * represents the edges of a Graph of Towns
 * 
 * @author Anusha Basnyat
 * 
 */

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Road implements Comparable<Road>{

	private Town source;
	private Town destination;
	private String name;
	private int weight;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Set<Town> Towns = new HashSet();
	
	public Road(Town source, Town destination, int weight, String name) {
		
		this.name = name;
		this.weight = weight;
		Towns.add(source);
		Towns.add(destination);
	}

	/**
	 * 
	 */
	public int compareTo(Road o) {

		return this.getWeight() - o.getWeight();
	}

	/**
	 * returns true only if the edge contains the given town
	 * 
	 * @param town
	 * @return
	 */
	public boolean contains(Town town) {
		
		if(town.compareTo(source) == 0 || town.compareTo(destination) == 0)
			
			return true;
		
		else 
			
			return false;
	}

	/**
	 * returns true if each of the ends of the road r is the same as the ends of this road
	 * remember that a road that goes from point A to point B is the same as a road that goes from point B to point A
	 * 
	 * @param r
	 * @return
	 */
	public boolean equals(Road r) {
		
		if(r.source.compareTo(source) == 0 && r.destination.compareTo(destination) == 0)
			
			return true;
		
		else
			
			return false;
	}

	/**
	 * returns the second town on the road
	 * 
	 * @return
	 */
	public Town getDestination() {
		
		return destination;
	}

	/**
	 * returns the road name
	 * 
	 * @return
	 */
	public String getName() {
		
		return name;
	}

	/**
	 * returns the first town on the road
	 * 
	 * @return
	 */
	public Town getSource() {
		
		return source;
	}

	/**
	 * returns the distance of the road
	 * 
	 * @return
	 */
	public int getWeight() {
		
		return weight;
	}

	
	public int hashCode() {
		
		final int prime = 31;
		
		int res = 1;
		
		res = prime * res + ((Towns == null) ? 0 : Towns.hashCode());
		res = prime * res + ((name == null) ? 0 : name.hashCode());
		res = prime * res + weight;
		
		return res;
	}
	
	public boolean equals(Object o) {
		
		if (this == o)
			
			return true;
		
		if (o == null)
			
			return false;
		
		if (getClass() != o.getClass())
			
			return false;
		
		Road other = (Road) o;
		
		if (Towns == null) {
			
			if (other.Towns != null)
				
				return false;
		}
		else if (!Towns.equals(other.Towns))
			
			return false;
		
		return true;
	}

	/**
	 * @return the Towns
	 */
	public Set<Town> getTowns() {
		
		return Towns;
	}
	
	/**
	 * @param Towns the Towns to set
	 */
	public void setTowns(Set<Town> Towns) {
		
		this.Towns = Towns;
	}

	/**
	 * To string method
	 */
	public String toString() {
		
		return name;
	}
}




