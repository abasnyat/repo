/**
 * @author Anusha Basnyat
 * 
 */

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


public class TownGraphManager implements TownGraphManagerInterface {
	
	private TownGraph graph = new TownGraph();
	private ArrayList<String> roadL = new ArrayList<String>();
	private ArrayList<String> townL = new ArrayList<String>();
	
	/**
	 * 
	 * @return
	 */
	public boolean populateTownGraph() {
		
		throw new UnsupportedOperationException("The method is not implemented yet.");
	}

	/**
	 * 
	 */
	public ArrayList<String> allRoads() {
		
		ArrayList<String> sortedRoads = new ArrayList<String>();

		sortedRoads = roadL;

		Collections.sort(sortedRoads);

		return sortedRoads;
	}

	/**
	 * 
	 */
	public ArrayList<String> allTowns() {
		
		ArrayList<String> sortedTowns = new ArrayList<String>();
		sortedTowns = townL;
		Collections.sort(sortedTowns);
		return sortedTowns;
	}

	/**
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public boolean populateTownGraph(File file) throws IOException {
		
		return false;
	}
	
	/**
	 * 
	 */
	public Town getTown(String name) {
		
		Set <Town> town = graph.vertexSet();
		
		for(Town t : town) {
			
			if(t.getName().equals(name)) {
			
				return t;
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param name
	 * @param a
	 * @param b
	 * @return
	 */
	public int getRoad(String name,Town a, Town b) {
		
		Set <Road> roads = graph.edgeSet();
		
		for(Road t : roads) {
			
			Set<Town> towns = new HashSet<Town>();
			towns.add(a);
			towns.add(b);
			
			if(t.getName().equals(name)) {
				
				if(t.getTowns().equals(towns)) {
					
					return t.getWeight();
				}
			}
		}
		return Integer.MAX_VALUE;
	}
	
	/**
	 * 
	 */
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		
		Town newTown1 = getTown(town1);
		Town newTown2 = getTown(town2);
		
		if(graph.containsVertex(newTown1) && graph.containsVertex(newTown2)) {
			
			if(!graph.containsEdge(newTown1, newTown2)) {
				
				graph.addEdge(newTown1, newTown2, weight, roadName);
				Road road = graph.addEdge(newTown1, newTown2, weight, roadName);
				
				roadL.add(road.getName());
				
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 */
	public String getRoad(String town1, String town2) {
		
		Town newTown1 = getTown(town1);
		Town newTown2 = getTown(town2);
		
		if(graph.containsEdge(newTown1, newTown2)) {
			
			Road road = graph.getEdge(newTown1, newTown2);
			return road.getName();
		}
		return null;
	}

	/**
	 * 
	 */
	public boolean addTown(String v) {
		
		Town town = new Town(v);
		
		if(!graph.containsVertex(town)) {
			
			graph.addVertex(town);
			townL.add(v);
			return true;
		}
		return false;
	}

	/**
	 * 
	 */
	public boolean containsTown(String v) {
		
		return graph.containsVertex(getTown(v));
	}

	/**
	 * 
	 */
	public boolean containsRoadConnection(String town1, String town2) {
		
		Town newTown1 = new Town(town1);
		Town newTown2 = new Town(town2);
		
		return graph.containsEdge(newTown1, newTown2);
	}

	/**
	 * 
	 */
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		
		Town newTown1 = getTown(town1);
		Town newTown2 = getTown(town2);
		
		if(graph.containsEdge(newTown1, newTown2) == true) {
			
			graph.removeEdge(newTown1, newTown2, getRoad(road, newTown1, newTown2), road);
			roadL.remove(road);
			return true;
		}
		return false;
	}

	/**
	 * 
	 */
	public boolean deleteTown(String v) {
		
		Town newTown = getTown(v);
		
		if(graph.containsVertex(newTown)) {
			
			graph.removeVertex(newTown);
			townL.remove(v);
			return true;
		}
		return false;
	}

	/**
	 * 
	 */
	public ArrayList<String> getPath(String town1, String town2) {
		
		Town newTown1 = getTown(town1);
		Town newTown2 = getTown(town2);
		
		if(graph.containsVertex(newTown2) && graph.containsVertex(newTown1)) {
			
			return graph.shortestPath(newTown1, newTown2);
		}
		return null;
	}
}




