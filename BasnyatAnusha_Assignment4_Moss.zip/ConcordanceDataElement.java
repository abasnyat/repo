import java.util.LinkedList;

/**
 * This is the class representation of the concordance
 * @Anusha Basnyat 
 */

public class ConcordanceDataElement implements Comparable<ConcordanceDataElement> 
{
	LinkedList<Integer> LINKED_LIST;
	String word;
	
	public ConcordanceDataElement(String word) 
{
		this.word = word;
		LINKED_LIST = new LinkedList<Integer>();
	}


	public String toString() 
{
		int x=0;
		String txt = "";
		while (x<LINKED_LIST.size()) {
			txt = txt + LINKED_LIST.get(x) + ((x==LINKED_LIST.size()-1) ? "":", ");
			x++;
		}
		return this.word + ": " + txt;
	}

	@Override
	public int compareTo(ConcordanceDataElement element) 
{
		throw new UnsupportedOperationException();
	}
	
	
	
	public int hashCode() 
       {
		return word.hashCode();

	}

        public LinkedList<Integer> getList()
        {
		return LINKED_LIST;
	}

        public String getWord() 
       {
		return this.word;
	}
	

	
	public void addPage(int LineNumber) {
		int x=0;
		while (x<LINKED_LIST.size()) {
			if (LineNumber == LINKED_LIST.get(x)) return;
			x++;
		}
		LINKED_LIST.add(LineNumber);
	}
}
