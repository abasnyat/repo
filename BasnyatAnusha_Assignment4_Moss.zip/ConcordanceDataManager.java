import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * This is the manager class responsible for creating an array of
 * a concordance or a file of a concordance
 * @author Anusha Basnyat
 */


public class ConcordanceDataManager implements ConcordanceDataManagerInterface 
{

	@Override
	public ArrayList<String> createConcordanceArray(String input) 
{
		ConcordanceDataStructure structure = new ConcordanceDataStructure(input.length());
		Scanner inputScan = new Scanner(input);
		int line = 1;
		while (inputScan.hasNextLine()) 
{
			String txt = inputScan.nextLine();
			txt = txt.replaceAll("[,.]","");
			int x=0;
			String w[] = txt.split(" ");
			while (x<w.length) {
				String w1 = w[x].toLowerCase();
				if (w1.length()>=3 && !w1.equals("and") && !w1.equals("the"))
				{
					structure.add(w1, line);
				}
				x++;
			}
			line++;
		}
		inputScan.close();
		ArrayList<String> ARRAY = structure.showAll();
		int x=0;
		while (x<ARRAY.size()) {
			ARRAY.set(x,  ARRAY.get(x)+"\n");
			x++;
		}
		return ARRAY;
	}

	@Override
	public boolean createConcordanceFile(File input, File output) throws FileNotFoundException {
		try {
			ConcordanceDataStructure structure = new ConcordanceDataStructure(500);
			Scanner inputScan = new Scanner(input);			
			int line=1;
			while (inputScan.hasNextLine())
 {
				String txt = inputScan.nextLine();
				txt = txt.replaceAll("[,.]","");
				int x=0;
				String w[] = txt.split(" ");
				while (x<w.length) 
{
					String w1 = w[x].toLowerCase();
					if (w1.length()>=3 && !w1.equals("and") && !w1.equals("the"))
					{
						structure.add(w1, line);
					}
					x++;
				}
				line++;
			}
			inputScan.close();
			ArrayList<String> ARRAY = structure.showAll();

			PrintWriter writeOutput = new PrintWriter(output);
			for (int x=0;x<ARRAY.size();x++) 
{
				writeOutput.println(ARRAY.get(x));
			}
			writeOutput.close();
		}
		catch (Exception e){
			throw new FileNotFoundException();
		}
		return false;
	}

}
