import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Collections; 

/**
 * This class is the data structure for the concordance
 * @author Anusha Basnyat 
 */


public class ConcordanceDataStructure implements ConcordanceDataStructureInterface 
{
	LinkedList<ConcordanceDataElement> ListArray[];
	int TABLE_SIZE = 0;

	public ConcordanceDataStructure(int number)
 {
		if (number==500) TABLE_SIZE = 347;
		else TABLE_SIZE = (int) (number/1.5);
		ListArray = new LinkedList[TABLE_SIZE];
		for (int x=0;x<TABLE_SIZE;x++) {
			ListArray[x] = new LinkedList<ConcordanceDataElement>();
		}
	}
	
	public ConcordanceDataStructure(String test, int size) 
{
		TABLE_SIZE = size;
		ListArray = new LinkedList[TABLE_SIZE];
		for (int x=0;x<TABLE_SIZE;x++) 
{
			ListArray[x] = new LinkedList<ConcordanceDataElement>();
		}
	}
	
	@Override
	public int getTableSize() 
{
		return TABLE_SIZE;
	}

	@Override
	public ArrayList<String> getWords(int index) 
{
		ArrayList<String> WORD = new ArrayList<String>();
		for (int x=0;x<ListArray[index].size();x++) {
			WORD.add(ListArray[index].get(x).getWord());
		}
		return WORD;
	}

	@Override
	public ArrayList<LinkedList<Integer>> getPageNumbers(int index) {
		ArrayList<LinkedList<Integer>> ArrayLinkedInteger = new ArrayList<LinkedList<Integer>>();
		for (int x=0;x<ListArray[index].size();x++) 

{
			ArrayLinkedInteger.add(ListArray[index].get(x).getList());
		}
		return ArrayLinkedInteger;
	}



	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> SHOWALLARRAY = new ArrayList<String>();
		int x=0;
		while (x<TABLE_SIZE) {
			int y=0;
			while (y<ListArray[x].size())
 {
				SHOWALLARRAY.add(ListArray[x].get(y).toString());
				y++;
			}
			x++;
		}
		SHOWALLARRAY.sort(String::compareToIgnoreCase);
		return SHOWALLARRAY;
	}
	
	@Override
	public void add(String word, int lineNum) 
{
		ConcordanceDataElement newConcordanceDataElement;
		int index = Math.abs(word.hashCode()%TABLE_SIZE);
		int x=0;
		while (x<ListArray[index].size()) 
{
			if (ListArray[index].get(x).getWord().equals(word)) 
{
				newConcordanceDataElement = ListArray[index].get(x);
				newConcordanceDataElement.addPage(lineNum);
				return;
			}
			x++;
		}
		newConcordanceDataElement = new ConcordanceDataElement(word);
		newConcordanceDataElement.addPage(lineNum);
		ListArray[index].add(newConcordanceDataElement);
	}

}
