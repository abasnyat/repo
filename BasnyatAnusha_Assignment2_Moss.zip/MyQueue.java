/**
 * 
 * @author anushab
 *
 */

public class MyQueue<T> implements QueueInterface<T> {

	private T myQueue[];
	private int size = 10;
	
	private int queueNum = 0;
	
	private int frontVal = 0;
	private int backVal = 0;
	
	//private QueueInterface<T> priority_queue;
	
	
	/**
	 * 
	 */
	public MyQueue() {
		myQueue = (T[]) new Object[size];
	}
	
	
	/**
	 * 
	 */
	public MyQueue(int q) {
		
		size = q;
		myQueue = (T[]) new Object[q];
	}
	
	
	/**
	 * 
	 */
	public boolean isEmpty() {
		
		return queueNum == 0;
	}

	
	/**
	 * 
	 */
	public boolean isFull() {
		
		if(queueNum >= myQueue.length) {
			return true;
		}
		
		else
			return false;
	}

	
	/**
	 * 
	 */
	public T dequeue() {
		
		T front;
		
		if(isEmpty()) {
			
			front = null;
		}
		
		else {
		
			front = myQueue[frontVal];
			
			frontVal = (frontVal +1) % size;
			
			queueNum--;
		}
		
		return front;
	}

	
	/**
	 * 
	 */
	public int size() {
		
		return queueNum;
	}

	
	/**
	 * 
	 */
	public boolean enqueue(T e) {
		
		if(isFull()) {
			
			return false;
		}
		
		else {
		
			myQueue[backVal] = e;
			
			backVal = (backVal + 1) % size;
			
			queueNum++;
		}
		
		return true;
	}

	
	/**
	 * 
	 */
	public T[] toArray() {
		
		int element = frontVal;
		
		T[] copy = (T[]) new Object[queueNum];
		
		for(int x = 0; x < queueNum; x++) {
			
			copy[x] = myQueue[element];
			
			element = (element + 1) % queueNum;
		}
		
		return copy; 
	}
}




