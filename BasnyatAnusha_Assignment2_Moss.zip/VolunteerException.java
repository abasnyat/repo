/**
 * volunteer exception
 * @author anushab
 *
 */

public class VolunteerException extends RuntimeException {
	
	public VolunteerException() {
		
	}
	
	VolunteerException(String message) {
		
		super(message);
	}
}




