/**
 * volunteer line class
 * @author anushab
 *
 */

public class VolunteerLine implements VolunteerLineInterface {
	
	private MyQueue volunteer;
	
	
	/**
	 * 
	 */
	public VolunteerLine() {
		
		volunteer = new MyQueue();
	}
	
	
	/**
	 * 
	 * @param size
	 */
	public VolunteerLine(int v) {
		
		volunteer = new MyQueue(v);
	}
	
	
	
	public boolean addNewVolunteer(Volunteer v) throws VolunteerException {
		
		if(volunteer.isFull()) {
			
			throw new VolunteerException("Volunteer Queue is full");
		}
		
		volunteer.enqueue(v);
		
		return true;
	}

	
	public Volunteer volunteerTurn() throws VolunteerException {
		
		if(volunteer.isEmpty()) {
			
			throw new VolunteerException("Volunteer Queue is empty");
		}
		
		return (Volunteer) volunteer.dequeue();
	}

	
	public boolean volunteerLineEmpty() {
		
		return volunteer.isEmpty();
	}

	
	public Volunteer[] toArrayVolunteer() {
		
		String theVolunteer = "";
		
		Object[] array = volunteer.toArray();
		
		Volunteer[] volunCopy = new Volunteer[array.length];
		
		for(int x = 0; x < volunteer.size(); x++) {
			
			theVolunteer = ((Volunteer) array[x]).getName();
			
			volunCopy[x] = new Volunteer(theVolunteer);
		}
		
		return volunCopy;
	}
}




