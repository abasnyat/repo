/**
 * recipient exception class
 * @author anushab
 *
 */

public class RecipientException extends RuntimeException {
	
	public RecipientException() {
		
	}
	
	RecipientException(String message) {
		
		super(message);
	}
}




