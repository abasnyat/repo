/**
 * recipient line class
 * @author anushab
 *
 */

public class RecipientLine implements RecipientLineInterface {
	
	private MyQueue recipient;
	
	
	/**
	 * 
	 */
	public RecipientLine() {
		
		recipient = new MyQueue();
	}
	
	
	/**
	 * 
	 * @param size
	 */
	public RecipientLine(int size) {

		recipient = new MyQueue(size);
	}

	
	/**
	 * 
	 */
	public boolean addNewRecipient(Recipient rc) throws RecipientException {
		
		if(recipient.isFull()) {
			
			throw new RecipientException("Recipient Queue is full");
		}
		
		recipient.enqueue(rc);
		
		return true;
	}

	
	/**
	 * 
	 */
	public Recipient recipientTurn() throws RecipientException {
		
		if(recipient.isEmpty()) {
			
			throw new RecipientException("Recipient Queue is empty");
		}
		
		return (Recipient) recipient.dequeue();
	}

	
	/**
	 * 
	 */
	public boolean recipientLineEmpty() {
		
		return recipient.isEmpty();
	}

	
	/**
	 * 
	 */
	public Recipient[] toArrayRecipient() {
		
		String theRecipient = "";
		
		Object[] array = recipient.toArray();
		
		Recipient[] reciCopy = new Recipient[array.length];
		
		for(int x=0; x<recipient.size(); x++) {
		
			theRecipient = ((Recipient) array[x]).getName();
			
			reciCopy[x] = new Recipient(theRecipient);
		}
		
		return reciCopy;
	}
}




