/**
 * 
 * @author anushab
 *
 */

import java.util.*;


public class MyStack<T> implements StackInterface<T> {

	private static final int capacity = 10;
	
	private T myStack[];
	
	private int size = 0;
	private int stackCap = 0;
	private int top = 0;
	
	
	/**
	 * 
	 */
	public MyStack() {
		
		stackCap = capacity;
		
		myStack = (T[]) new Object [capacity];
		
	}
	
	
	/**
	 * 
	 * @param i
	 */
	public MyStack(int s) {
		
		stackCap = s;
		
		myStack = (T[]) new Object[s];
	}
	
	
	/**
	 * 
	 */
	public boolean isEmpty() {
		
		return size == 0;
	}

	
	/**
	 * 
	 */
	public boolean isFull() {
		
		return size == stackCap;
	}

	
	/**
	 * 
	 */
	public T pop() {
		
		T topVal;
		
		if(isEmpty()) {
			
			return null;
		}
		
		else {
			
			topVal = myStack[--top];
			
			size--;
		}
		
		return topVal;
	}

	
	/**
	 * 
	 */
	public int size() {
		
		return size;
	}

	
	/**
	 * 
	 */
	public boolean push(T e) {
		
		if(isFull()) {
			
			return false;
		}
		
		else {
			
			myStack[top] = e;
			
			top += 1;
			size +=1;
		}
		
		return true;
	}

	
	/**
	 * 
	 */
	public T[] toArray() {
		
		int element = size - 1;
		
		T[] copy = (T[]) new Object[size];
		
		for(int i = 0; i < size; i++) {
			
			copy[i] = myStack[element--];
		}
		
		return copy;
	}
}




