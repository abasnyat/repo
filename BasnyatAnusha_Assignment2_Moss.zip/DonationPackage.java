/**
 * Donation Package class
 * @author anushab
 *
 */

public class DonationPackage {
	
	private String description;
	private int weight;
	
	
	/**
	 * 
	 * @param description
	 * @param weight
	 */
	public DonationPackage(String description, int weight) {
		
		this.description = description;
		this.weight = weight;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public String getDescription() {
		
		return description;
	}
	
	
	/**
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		
		this.description = description;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public int getWeight() {
		
		return weight;
	}
	
	
	/**
	 * 
	 * @param weight
	 */
	public void setWeight(int weight) {
		
		this.weight = weight;
	}

	
	/**
	 * 
	 * @return
	 */
	public boolean isHeavy() {
		
		if(weight > 20)
			return true;
		
		else
			return false;
	}
}




